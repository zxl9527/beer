import json
import requests
import time
from bs4 import BeautifulSoup
import pandas as pd
from multiprocessing import Pool

# 定义起始和结束日期
start_year = 2022  # 起始年份
start_month = 5  # 起始月份
end_year = 2024  # 结束年份
end_month = 5  # 结束月份

# 定义基础URL
base_url = "https://tianqi.2345.com/Pc/GetHistory?areaInfo%5BareaId%5D=57516&areaInfo%5BareaType%5D=2&date%5Byear%5D="

# 创建一个空列表来存储所有生成的URL
urls = []

# 循环遍历从起始年份到结束年份的每一年
for year in range(start_year, end_year + 1):
    # 循环遍历一年中的每个月
    for month in range(1, 13):
        # 如果是起始年份但月份小于起始月份，则跳过
        if year == start_year and month < start_month:
            continue
        # 如果是结束年份但月份大于结束月份，则终止循环
        if year == end_year and month > end_month:
            break
        # 使用字符串格式化来创建完整的URL
        url = base_url + "{}&date%5Bmonth%5D={}".format(year, month)
        # 将生成的URL添加到列表中
        urls.append((url, year, month))  # 将年份和月份与URL一起存储

headers = {
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-encoding': 'gzip, deflate, br, zstd',
    'accept-language': 'zh-CN,zh;q=0.9',
    'connection': 'keep-alive',
    'host': 'tianqi.2345.com',
    'referer': 'https://tianqi.2345.com/wea_history/57516.htm',
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0"
}

cookies = {
    "Cookie": "Hm_lvt_a3f2879f6b3620a363bec646b7a8bcdd=1722601615,1722651149,1723295748,1723478233; lastCountyId=57516; lastCountyTime=1723478247; lastCountyPinyin=chongqing; lastProvinceId=43; lastCityId=57516; Hm_lpvt_a3f2879f6b3620a363bec646b7a8bcdd=1723478248; HMACCOUNT=1B2E3FDA9AE70018"
}


def get_html(args):
    url, year, month = args
    print(f"正在爬取 {year} 年 {month} 月的数据...")
    response = requests.get(url, headers=headers, cookies=cookies)
    if response.status_code == 200:
        return response.text, year, month
    return None, year, month


def parse_html(data):
    html_text, year, month = data
    weather_data = []
    if html_text:
        json_data = json.loads(html_text)
        if 'data' in json_data:
            html_content = json_data['data']
            soup = BeautifulSoup(html_content, 'html.parser')

            # 查找所有的<tr>标签（除了表头）
            for row in soup.find_all('tr')[1:]:  # 跳过表头
                cols = row.find_all('td')
                date = cols[0].get_text(strip=True)
                max_temp = cols[1].get_text(strip=True)
                min_temp = cols[2].get_text(strip=True)
                weather = cols[3].get_text(strip=True)
                wind = cols[4].get_text(strip=True)
                aqi = cols[5].find('span').get_text(strip=True)

                weather_data.append({
                    '日期': date,
                    '最高温': max_temp,
                    '最低温': min_temp,
                    '天气': weather,
                    '风力风向': wind,
                    '空气质量指数': aqi
                })
    return weather_data


def main():
    start_time = time.time()

    # 使用多进程池
    with Pool(processes=8) as pool:
        # 爬取HTML内容
        html_results = pool.map(get_html, urls)
        # 解析HTML内容
        weather_data = pool.map(parse_html, html_results)

    # 展平列表
    weather_data = [item for sublist in weather_data for item in sublist]

    # 保存结果到Excel文件
    results = pd.DataFrame(weather_data)
    results['日期'] = results['日期'].str.replace(' 周日', '').str.replace(' 周一', '').str.replace(' 周二', '').str.replace(
        ' 周三', '').str.replace(' 周四', '').str.replace(' 周五', '').str.replace(' 周六', '')
    results.to_excel("E://桌面//chongqingshi.xlsx", index=False)
    print(f"数据已保存到 'chongqingshi.xlsx'")

    end_time = time.time()
    print(f"总用时: {end_time - start_time:.2f} 秒")


if __name__ == "__main__":
    main()


#2.89 秒